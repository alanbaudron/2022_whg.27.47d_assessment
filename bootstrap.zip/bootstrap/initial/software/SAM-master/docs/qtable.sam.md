# `qtable.sam`: table of survey catchabilities

## Description


 table of survey catchabilities


## Usage

```r
list(list("qtable"), list("sam"))(fit, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     A sam fit as returned from the sam.fit function
```...```     |     extra arguments not currently used


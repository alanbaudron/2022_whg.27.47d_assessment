# `qtableplot`: plot survey catchabilities

## Description


 plot survey catchabilities
 
 plot survey catchabilities


## Usage

```r
qtableplot(qt, exp = FALSE)
list(list("qtableplot"), list("samqtable"))(qt, exp = FALSE)
```


## Arguments

Argument      |Description
------------- |----------------
```qt```     |     An object of class 'samqtable' as returned from qtable
```exp```     |     if true return on natural scale rather than log


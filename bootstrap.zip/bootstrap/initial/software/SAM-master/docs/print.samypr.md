# `print.samypr`: Print samypr object

## Description


 Print samypr object


## Usage

```r
list(list("print"), list("samypr"))(x, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     an object as returned from the ypr function
```...```     |     extra arguments

## Details


 ...



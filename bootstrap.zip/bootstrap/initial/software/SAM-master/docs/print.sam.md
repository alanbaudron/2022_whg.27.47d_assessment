# `print.sam`: Print sam object

## Description


 Print sam object


## Usage

```r
list(list("print"), list("sam"))(x, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     the fitted object as returned from the [`sam.fit`](sam.fit.html) function
```...```     |     extra arguments

## Details


 prints the log-likelihood and the main convergence criteria



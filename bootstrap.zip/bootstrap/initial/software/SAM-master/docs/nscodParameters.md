# `nscodParameters`: 
 nscodParameters


## Description


 nscodParameters


## Format


 The format is:
 List of 14
 $ logFpar
 $ logQpow
 $ logSdLogFsta
 $ logSdLogN
 $ logSdLogObs
 $ rec_loga
 $ rec_logb
 $ itrans_rho
 $ logScale
 $ logScaleSSB
 $ logPowSSB
 $ logSdSSB
 $ logF
 $ logN


## Usage

```r
data("nscodParameters")```


## Details


 ...


## References


 ...


## Examples

```r 
 data(nscodParameters)
 ## maybe str(nscodParameters) ; plot(nscodParameters) ...
 ``` 


# `modelVersionInfo`: Description of model

## Description


 Description of model


## Usage

```r
modelVersionInfo(fit, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     returned object from sam.fit
```...```     |     Additional parameters to be passed to ...

## Details


 Writes a string to install the version of the package which was used to run the model.



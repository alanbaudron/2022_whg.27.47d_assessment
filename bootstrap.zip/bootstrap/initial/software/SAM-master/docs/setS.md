# `setS`: small helper function

## Description


 small helper function


## Usage

```r
setS(x)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     vector if indices

## Details


 internal



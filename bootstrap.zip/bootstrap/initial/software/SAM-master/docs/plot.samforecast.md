# `plot.samforecast`: Plot samforecast object

## Description


 Plot samforecast object


## Usage

```r
list(list("plot"), list("samforecast"))(x, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     fitted object as returned from the [`sam.fit`](sam.fit.html) function
```...```     |     extra arguments

## Details


 ...



# `nscodData`: 
 nscodData


## Description


 nscodData


## Format


 The format is:
 $ noFleets
 $ fleetTypes
 $ sampleTimes
 $ noYears
 $ years
 $ nobs
 $ idx1
 $ idx2
 $ aux
 $ logobs
 $ propMat
 $ stockMeanWeight
 $ catchMeanWeight
 $ natMor
 $ landFrac
 $ disMeanWeight
 $ landMeanWeight
 $ propF
 $ propM


## Usage

```r
data("nscodData")```


## Details


 ...


## References


 ...


## Examples

```r 
 data(nscodData)
 ## maybe str(nscodData) ; plot(nscodData) ...
 ``` 


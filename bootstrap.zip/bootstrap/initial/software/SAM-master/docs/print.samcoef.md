# `print.samcoef`: Print samcoef object

## Description


 Print samcoef object


## Usage

```r
list(list("print"), list("samcoef"))(x, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     samcoef object as returned from the [`coef.sam`](coef.sam.html) function
```...```     |     extra arguments


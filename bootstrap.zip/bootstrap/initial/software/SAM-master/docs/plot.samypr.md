# `plot.samypr`: Plot sam object

## Description


 Plot sam object


## Usage

```r
list(list("plot"), list("samypr"))(x, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     ...
```...```     |     extra arguments

## Details


 ...



# `logLik.sam`: Log likelihood of sam object

## Description


 Log likelihood of sam object


## Usage

```r
list(list("logLik"), list("sam"))(object, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```object```     |     sam fitted object as returned from the [`sam.fit`](sam.fit.html) function
```...```     |     extra arguments

## Details


 log likelihood of a sam model run



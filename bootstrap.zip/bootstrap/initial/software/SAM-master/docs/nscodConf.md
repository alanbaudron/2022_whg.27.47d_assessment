# `nscodConf`: 
 nscodConf


## Description


 nscodConf


## Format


 The format is:
 $ minAge
 $ maxAge
 $ maxAgePlusGroup
 $ keyLogFsta
 $ corFlag
 $ keyLogFpar
 $ keyQpow
 $ keyVarF
 $ keyVarLogN
 $ keyVarObs
 $ stockRecruitmentModelCode
 $ noScaledYears
 $ keyScaledYears
 $ keyParScaledYA
 $ fbarRange


## Usage

```r
data("nscodConf")```


## Details


 ...


## References


 ...


## Examples

```r 
 data(nscodConf)
 ## maybe str(nscodConf) ; plot(nscodConf) ...
 ``` 


# `is.whole.positive.number`: Function to test if x is ...

## Description


 Function to test if x is ...


## Usage

```r
is.whole.positive.number(x, tol = .Machine$double.eps^0.5)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     number
```tol```     |     precision

## Details


 ...



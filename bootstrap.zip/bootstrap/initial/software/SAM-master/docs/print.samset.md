# `print.samset`: Print samset object

## Description


 Print samset object


## Usage

```r
list(list("print"), list("samset"))(x, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     a list of sam models
```...```     |     extra arguments

## Details


 ...



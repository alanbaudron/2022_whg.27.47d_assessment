# `faytable`: F-at-age table

## Description


 F-at-age table


## Usage

```r
faytable(fit, ...)
list(list("faytable"), list("sam"))(fit, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     ...
```...```     |     extra arguments not currently used

## Details


 ...



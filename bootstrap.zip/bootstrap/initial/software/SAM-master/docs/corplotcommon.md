# `corplotcommon`: Common function for plotting correlation matrices.

## Description


 Common function for plotting correlation matrices.


## Usage

```r
corplotcommon(x, fn, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     a list of correlation matrices
```fn```     |     a vector of fleet names
```...```     |     extra arguments to plotcorr


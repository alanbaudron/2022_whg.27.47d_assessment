# `partable`: parameter table

## Description


 parameter table


## Usage

```r
partable(fit, ...)
list(list("partable"), list("sam"))(fit, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     ...
```...```     |     extra arguments not currently used

## Details


 ...



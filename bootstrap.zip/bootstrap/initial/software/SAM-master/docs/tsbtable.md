# `tsbtable`: TSB table

## Description


 TSB table


## Usage

```r
tsbtable(fit, ...)
list(list("tsbtable"), list("default"))(fit, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     ...
```...```     |     extra arguments not currently used

## Details


 ...



# `summary.sam`: Summary of sam object

## Description


 Summary of sam object


## Usage

```r
list(list("summary"), list("sam"))(object, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```object```     |     sam fitted object as returned from the [`sam.fit`](sam.fit.html) function
```...```     |     extra arguments

## Details


 summary table containing recruits, SSB, and Fbar



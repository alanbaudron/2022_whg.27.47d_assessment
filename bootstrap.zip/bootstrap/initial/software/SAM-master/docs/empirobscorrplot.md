# `empirobscorrplot`: Plots the residual between-age correlation matrices by fleet.

## Description


 Plots the residual between-age correlation matrices by fleet.


## Usage

```r
empirobscorrplot(res, ...)
list(list("empirobscorrplot"), list("samres"))(res, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```res```     |     the object returned from residuals.sam
```...```     |     extra arguments to plot


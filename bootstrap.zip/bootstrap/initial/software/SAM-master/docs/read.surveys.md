# `read.surveys`: Function to read ices survey format

## Description


 Function to read ices survey format


## Usage

```r
read.surveys(filen)
```


## Arguments

Argument      |Description
------------- |----------------
```filen```     |     the file

## Details


 ...



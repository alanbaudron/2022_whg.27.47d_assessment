# `getUpperBounds`: Bounds

## Description


 Bounds


## Usage

```r
getUpperBounds(parameters)
```


## Arguments

Argument      |Description
------------- |----------------
```parameters```     |     initial values for the model in a format similar to what is returned from the defpar function

## Value


 a named list



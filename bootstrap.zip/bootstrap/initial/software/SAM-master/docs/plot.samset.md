# `plot.samset`: Plot sam object

## Description


 Plot sam object


## Usage

```r
list(list("plot"), list("samset"))(x, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     fitted object as returned from the [`sam.fit`](sam.fit.html) function.
```...```     |     extra arguments

## Details


 ...



# `fbartable`: Fbar table

## Description


 Fbar table


## Usage

```r
fbartable(fit, ...)
list(list("fbartable"), list("default"))(fit, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     ...
```...```     |     extra arguments not currently used

## Details


 ...



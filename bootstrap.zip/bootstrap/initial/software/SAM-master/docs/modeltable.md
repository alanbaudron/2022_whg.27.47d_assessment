# `modeltable`: model table

## Description


 model table


## Usage

```r
modeltable(fits, ...)
list(list("modeltable"), list("sam"))(fits, ...)
list(list("modeltable"), list("samset"))(fits, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fits```     |     A sam fit as returned from the sam.fit function, or a collection c(fit1, fit2, ...) of such fits
```...```     |     extra arguments not currently used

## Details


 ...



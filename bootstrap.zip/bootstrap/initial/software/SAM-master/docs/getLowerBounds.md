# `getLowerBounds`: Bounds

## Description


 Bounds


## Usage

```r
getLowerBounds(parameters)
```


## Arguments

Argument      |Description
------------- |----------------
```parameters```     |     initial values for the model in a format similar to what is returned from the defpar function

## Value


 a named list



# `setSeq`: small helper function

## Description


 small helper function


## Usage

```r
setSeq(min, max)
```


## Arguments

Argument      |Description
------------- |----------------
```min```     |     from
```max```     |     to

## Details


 internal



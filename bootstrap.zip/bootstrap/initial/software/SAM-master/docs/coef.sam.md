# `coef.sam`: Extract fixed coefficients of sam object

## Description


 Extract fixed coefficients of sam object


## Usage

```r
list(list("coef"), list("sam"))(object, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```object```     |     sam fitted object as returned from the [`sam.fit`](sam.fit.html) function
```...```     |     extra arguments

## Details


 fixed coefficients of sam object



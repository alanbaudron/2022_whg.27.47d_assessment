# `ssbtable`: SSB table

## Description


 SSB table


## Usage

```r
ssbtable(fit, ...)
list(list("ssbtable"), list("default"))(fit, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     ...
```...```     |     extra arguments not currently used

## Details


 ...



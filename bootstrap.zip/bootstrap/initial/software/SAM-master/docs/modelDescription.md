# `modelDescription`: Description of model

## Description


 Description of model


## Usage

```r
modelDescription(fit, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     returned object from sam.fit
```...```     |     Additional parameters to be passed to ...

## Details


 ...



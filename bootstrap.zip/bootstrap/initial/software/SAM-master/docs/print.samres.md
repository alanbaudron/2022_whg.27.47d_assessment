# `print.samres`: Print samres object

## Description


 Print samres object


## Usage

```r
list(list("print"), list("samres"))(x, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     a sam residual object as returnd from either [`residuals.sam`](residuals.sam.html) or [`procres`](procres.html)
```...```     |     extra arguments

## Details


 prints the residuals as a data.frame



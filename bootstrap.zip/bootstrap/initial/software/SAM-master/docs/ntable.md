# `ntable`: N table

## Description


 N table


## Usage

```r
ntable(fit, ...)
list(list("ntable"), list("sam"))(fit, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     ...
```...```     |     extra arguments not currently used

## Details


 ...



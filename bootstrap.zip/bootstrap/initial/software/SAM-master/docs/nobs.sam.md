# `nobs.sam`: Extract number of observations from sam object

## Description


 Extract number of observations from sam object


## Usage

```r
list(list("nobs"), list("sam"))(object, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```object```     |     sam fitted object as returned from the [`sam.fit`](sam.fit.html) function
```...```     |     extra arguments

## Details


 ...



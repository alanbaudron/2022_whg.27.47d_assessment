# `catchtable`: Catch table

## Description


 Catch table


## Usage

```r
catchtable(fit, obs.show = FALSE, ...)
list(list("catchtable"), list("sam"))(fit, obs.show = FALSE, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     ...
```obs.show```     |     logical add a column with catch sum of product rowsums(C*W)
```...```     |     extra arguments not currently used

## Details


 ...



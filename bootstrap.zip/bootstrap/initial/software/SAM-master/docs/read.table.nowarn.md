# `read.table.nowarn`: Function to supress incomplete final line warning

## Description


 Function to supress incomplete final line warning


## Usage

```r
read.table.nowarn(...)
```


## Arguments

Argument      |Description
------------- |----------------
```...```     |     arguments

## Details


 ...



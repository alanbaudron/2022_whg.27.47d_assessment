# `rectable`: Recruit table

## Description


 Recruit table


## Usage

```r
rectable(fit, lagR = FALSE, ...)
list(list("rectable"), list("default"))(fit, lagR = FALSE, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     ...
```lagR```     |     use the age after the youngest as R
```...```     |     extra arguments not currently used

## Details


 ...



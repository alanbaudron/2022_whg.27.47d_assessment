# `c.sam`: Collect sam objects

## Description


 Collect sam objects


## Usage

```r
list(list("c"), list("sam"))(...)
```


## Arguments

Argument      |Description
------------- |----------------
```...```     |     one or more sam fits (as returned from the [`sam.fit`](sam.fit.html) function) to be combined

## Details


 ...



# `obscorrplot`: Plots the estimated correlation matrices by fleet.

## Description


 Plots the estimated correlation matrices by fleet.


## Usage

```r
obscorrplot(fit, ...)
list(list("obscorrplot"), list("sam"))(fit, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     the object returned from sam.fit
```...```     |     extra arguments to plot


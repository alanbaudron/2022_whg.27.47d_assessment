# `print.samforecast`: Print samforecast object

## Description


 Print samforecast object


## Usage

```r
list(list("print"), list("samforecast"))(x, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```x```     |     an object as returned from the forecast function
```...```     |     extra arguments

## Details


 ...



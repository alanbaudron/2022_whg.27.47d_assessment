# `qtable`: table of survey catchabilities

## Description


 table of survey catchabilities


## Usage

```r
qtable(fit, ...)
```


## Arguments

Argument      |Description
------------- |----------------
```fit```     |     ...
```...```     |     extra arguments not currently used

## Details


 ...


